EFWH 2.3.0 — Offline installer

This bundle contains the complete EFWH Claude Code Skill.
It does not require GitHub, Git, npm, or the npm registry after download.

Windows:
  Double-click install.cmd
  or run:  powershell -ExecutionPolicy Bypass -File .\install.ps1

macOS / Linux:
  ./install.sh

Destination:
  $CLAUDE_CONFIG_DIR/skills/efwh when CLAUDE_CONFIG_DIR is set,
  otherwise ~/.claude/skills/efwh.

Existing differing installs are backed up before replacement.
After installation, start Claude Code and use:
  /efwh <what you're trying to solve>
